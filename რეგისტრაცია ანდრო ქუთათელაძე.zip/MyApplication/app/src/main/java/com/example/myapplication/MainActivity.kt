package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val name = findViewById<EditText>(R.id.editname)
        val surname = findViewById<EditText>(R.id.editsurname)
        val mobilenum = findViewById<EditText>(R.id.editmblNum)
        val ID = findViewById<EditText>(R.id.editID)
        val btn_click = findViewById<Button>(R.id.button)

        btn_click.set0nclickListener {

            val resultName=name.text.toString()
            val resultSurname=surname.text.toString()
            val resultMnum=mobilenum.text.toString()
            val resultID=ID.text.toString()


            if (resultName == "" || resultSurname == "" || resultMnum == "" || resultID == ""){
                Toast.makeText(this@MainActivity, "გრაფა ცარიელია", Toast.LENGTH_SHORT).show()
            }else if(ID.length() < 11 ){
                Toast.makeText(this@MainActivity, "პირადი ნომერი არასწორია", Toast.LENGTH_SHORT).show()
            }else if(mobilenum.length() < 9){
                Toast.makeText(this@MainActivity, "მობილური ტელეფონის ნომერი არასწორია", Toast.LENGTH_SHORT).show()
            }else if(name.length() < 3){
                Toast.makeText(this@MainActivity, "სახელი არასწორია", Toast.LENGTH_SHORT).show()
            }else if(surname.length() < 5){
                Toast.makeText(this@MainActivity, "გვარი არასწორია", Toast.LENGTH_SHORT).show()
            }else if(resultName.any(it.isDigit())){
                    Toast.makeText(this@MainActivity, "სახელი არასწორია", Toast.LENGTH_SHORT).show()
            }else if(resultSurname.any(it.isDigit())) {
                    Toast.makeText(this@MainActivity, "გვარი არასწორია", Toast.LENGTH_SHORT).show()
            }else
                Toast.makeText(this@MainActivity, "თქვენ წარმატებით დარეგისტრირდით", Toast.LENGTH_SHORT).show()










        }
    }
}